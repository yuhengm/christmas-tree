# Christmas Tree CSS animation

This project is done following [YouTube tutorial](https://www.youtube.com/watch?v=SF9j1OSZDNU) by _The Brave Coders_.

<!-- Here is the [link](https://yuhengm.github.io/christmas-tree/) tp this project. -->

## Demo

![Christmas Tree](/demo/christmas-tree.gif)
